AC66U KoolShare固件最新版shadowsocks, 支持 obfs.  
支持 Cloudflare  