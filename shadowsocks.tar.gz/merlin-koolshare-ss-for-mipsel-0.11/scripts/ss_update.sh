#!/bin/sh

#eval `dbus export ss`

#sh /koolshare/ss/ssconfig.sh update